# 词芽芽 WordSprout — 手机英语学习卡片

## 主要功能
- 每天按手机本地日期自动切换 5 个词/词组
- 内置 240 个双语词条：日常沟通 80、新能源汽车 80、矿山工程 80
- 每条包括 IPA 音标、中文释义、英文例句、例句中文翻译
- 手机原生英语 TTS 朗读单词和例句，美式/英式英语、语速可调
- 点击「掌握啦」或「再练练」，自动安排隔天/3天/7天/14天/30天/60天间隔复习
- 收藏、搜索、已学词库、7天学习打卡、备份/恢复、新词导入
- 以 HTTPS 发布并成功打开一次后，可通过 Service Worker 缓存页面离线访问（语音取决于手机本地语音包）

## 立即体验
下载单文件 `index.html`，用支持网页脚本的浏览器打开。对于 iPhone，直接在「文件」App 预览 HTML 时，音频和本地持久存储可能受限制；建议通过 HTTPS 网站部署。

## 部署到手机（推荐）
1. 将本 ZIP 中的 `index.html`、`manifest.webmanifest`、`icon.svg`、`service-worker.js` 上传到一个支持静态网页 HTTPS 的主机。
2. 可以使用 GitHub Pages：新建公开仓库，上传以上四个文件；Settings → Pages → Deploy from a branch，选择 main 与根目录。
3. 在手机 Safari / Chrome 访问实际发布的网址。
4. iPhone：Safari → 分享 → 添加到主屏幕；Android：Chrome → 菜单 → 添加到主屏幕/安装应用。
5. 首次访问需联网，之后网页内容可离线打开。建议定期在「设置」里导出学习记录。

## 数据与日期
- 以 2026-10-10 为首日基准安排 48 天的学习表。前 48 天每天 5 个不同词；第 49 天起进入下一轮复习。
- 已学词、待复习词和收藏记录保存在浏览器 localStorage，不会自动同步到其他手机和浏览器。
- 清理浏览器网站数据或无痕模式可能删除进度。
- 浏览器朗读使用 Web Speech API。语音包离线可用性随设备/浏览器而变化。

## 导入额外词组
在「设置 → 导入备份 / 新词」选择 UTF-8 JSON 文件，例如：
```json
{
  "words": [
    {
      "category": "ev",
      "word": "Battery swap",
      "ipa": "/ˈbætəri swɑːp/",
      "zh": "换电",
      "example": "The truck uses a battery swap system.",
      "exampleZh": "这辆卡车采用换电系统。"
    }
  ]
}
```
category 可为 `daily`、`ev` 或 `mining`，默认 `daily`。
注意：新增词条按导入时刻追加到学习安排末尾，已学习日期对应的词条保持不变。

## 附件
- `index.html`：应用主文件（词库和逻辑已内置）
- `icon.svg`：应用图标
- `manifest.webmanifest`：手机桌面安装配置
- `service-worker.js`：离线缓存
- `words.json`：240 条词库，可自行编辑后按导入格式新增词条

## 限制
- 不含云端账号/跨设备自动同步、消息推送、真人语音录音。
- 新词不会自动从云端生成；首版 240 词可用于 48 天连续不重复学习，之后再次轮换。
